import { defineConfig, devices } from "@playwright/test";

export default defineConfig({
  testDir: "./e2e",
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: 1,
  reporter: "list",
  use: {
    baseURL: process.env.PLAYWRIGHT_BASE_URL ?? "http://localhost:5173",
    trace: "on-first-retry",
    actionTimeout: 15000,
  },
  timeout: 60000,
  projects: [{ name: "chromium", use: { ...devices["Desktop Chrome"] } }],
  // PLAYWRIGHT_SKIP_WEB_SERVER=1 のときは webServer を起動しない（既存の npm run dev を利用）
  ...(process.env.PLAYWRIGHT_SKIP_WEB_SERVER === "1"
    ? {}
    : {
        webServer: {
          command: "npm run dev",
          url: "http://localhost:5173",
          reuseExistingServer: true,
          timeout: 120000,
        },
      }),
});
