# OAuth 2.0 / OIDC 認可サーバー

OAuth 2.0 認可コードフロー + PKCE + OpenID Connect を実装した認可サーバー。

---

## アーキテクチャ概要

```
┌─────────────────┐         ┌─────────────────┐
│    Frontend     │  HTTP   │    Backend      │
│  (React/Vite)   │ ──────► │  (Go/Echo)      │
│  localhost:5173 │  API   │  localhost:8080 │
└────────┬────────┘         └────────┬────────┘
         │ credentials: include      │
         │ (Cookie: oauth_session)   │
         │                            │
         │                   ┌───────┴───────┐
         │                   │  PostgreSQL   │
         │                   │  Redis        │
         │                   └───────────────┘
```

| レイヤー | 責務 |
|----------|------|
| **Frontend** | ログイン・同意 UI。React Router で /login, /consent, /callback。AuthContext で認証状態管理。API 通信は `apiFetch` で分離。 |
| **Backend** | 認可 API（/oauth/authorize, /oauth/token）、セッション（/sessions/login）、Discovery、JWKS、UserInfo。JWT は RS256。 |
| **PostgreSQL** | ユーザー、クライアント、セッション、認可コード、トークン。 |
| **Redis** | 認可リクエスト（login_challenge）の一時保存。 |

**ステートレス**: アプリケーションサーバーは水平スケール可能。セッション・トークン・認可リクエストはすべて Postgres/Redis に保持。

---

## 起動手順

### 開発（DEV）

```bash
# 1. DB・Redis 起動
docker compose up -d postgres redis

# 2. マイグレーション・seed（初回のみ）
cd backend
PGPASSWORD=auth_pass psql -h localhost -U auth_user -d auth_db -f migrations/000_initial.sql
# 001〜005 も実行
./scripts/seed_step4.sh password123 http://localhost:5173/callback
cd ..

# 3. Backend 起動（別ターミナル）
cd backend && go run ./cmd/server

# 4. Frontend 起動（別ターミナル）
cd frontend && npm install && npm run dev
```

- **Backend**: http://localhost:8080  
- **Frontend**: http://localhost:5173  

### 本番（PROD）Docker Compose

```bash
docker compose -f docker-compose.yml -f compose.prod.yml up -d
```

### 全サービス Docker（開発用）

```bash
docker compose up -d
# Frontend は別途 npm run dev
```

---

## 環境変数一覧

提出物には `.env` 実体を含めません。`.env.example` をコピーして `.env` を作成してください。

```bash
cp backend/.env.example backend/.env
cp frontend/.env.example frontend/.env
```

### Frontend

| 変数 | 説明 |
|------|------|
| `VITE_API_BASE` | API ベース URL（例: http://localhost:8080） |

### Backend

| 変数 | 説明 |
|------|------|
| `DB_HOST` | PostgreSQL ホスト |
| `DB_PORT` | PostgreSQL ポート |
| `DB_USER` | DB ユーザー |
| `DB_PASSWORD` | DB パスワード |
| `DB_NAME` | DB 名 |
| `REDIS_HOST` | Redis ホスト |
| `REDIS_PORT` | Redis ポート |
| `OAUTH_ISSUER` | Issuer URL（本番は https 必須） |
| `SERVER_BASE_URL` | サーバー基底 URL |
| `LOGIN_URL` | ログイン画面 URL |
| `CONSENT_URL` | 同意画面 URL |
| `CORS_ORIGIN` | 許可する Origin（フロント URL） |

---

## 要件チェック表（満たし方 / 該当コード / テスト証跡）

| 要件 | 満たし方 | 該当コード | テスト証跡 |
|------|----------|------------|------------|
| ルーティング | React Router で /, /login, /consent, /callback を接続 | `frontend/src/App.tsx` | E2E: `e2e/oidc-flow.spec.ts` |
| 認証状態による画面制御 | RequireAuth で /consent を保護、未ログイン時は /login へ | `frontend/src/features/auth/RequireAuth.tsx` | Unit: `AuthContext.test.tsx` |
| 状態管理 | AuthContext で isAuthenticated を管理 | `frontend/src/features/auth/AuthContext.tsx` | Unit: `AuthContext.test.tsx` |
| API 通信層分離 | apiFetch で fetch をラップ、credentials/エラーハンドリング | `frontend/src/lib/api.ts` | Unit: `api.test.ts` |
| エラーハンドリング | ApiError 型で status/message を返却 | `frontend/src/lib/api.ts` | Unit: `api.test.ts` |
| ステートレスバックエンド | セッション・トークンは Postgres/Redis に保持 | `backend/internal/infrastructure/` | Integration / E2E |
| JWT RS256 | アクセストークン・ID Token を RSA 秘密鍵で署名 | `backend/internal/infrastructure/jwt/signer.go` | Unit: `signer_test.go` |
| CORS | 許可 Origin を env で制御 | `backend/internal/app/app.go` (CORS_ORIGIN) | - |

**証跡パス**: `backend/tests/evidence/`, `frontend/src/**/*.test.tsx`

---

## OpenAPI（Swagger）

API 仕様は OpenAPI 3.0 形式で定義しています。Swagger Editor に貼り付けて確認できます。

- **ファイル**: [docs/openapi.yaml](docs/openapi.yaml)

> **注意**: DBML（DB スキーマ）は dbdiagram.io / drawsql 向けです。Swagger Editor には OpenAPI YAML/JSON を貼り付けてください。

---

## テスト・証跡

```bash
# backend + frontend 起動後、プロジェクトルートから
./scripts/run_all_tests.sh
```

証跡は `backend/tests/evidence/` に保存。提出 zip に含めます。

---

## 提出物の作り方（火曜提出用）

**提出するのは `submission.zip` のみ。** `認可サーバー.zip`（手動で作った重い zip）は使わない。

### 手順

```bash
# 1. 証跡を最新にする（backend + frontend 起動済みのこと）
./scripts/run_all_tests.sh

# 2. 提出用 zip を作成
./scripts/create_submission_zip.sh

# 3. 提出: submission.zip を提出
```

### 除外されるもの（submission.zip に含まれない）

| 除外 | 理由 |
|------|------|
| `.env` | 秘密情報・環境依存 |
| `node_modules/` | 巨大・`npm install` で再現 |
| `frontend/dist/` | ビルド成果物・`npm run build` で再現 |
| `frontend/test-results/` | Playwright 一時ファイル |
| `.DS_Store`, `__MACOSX` | OS ノイズ |
| `cookies.txt` | E2E で生成される一時ファイル |
| `.git/` | リポジトリ履歴 |

### 第三者が迷わず動かすための確認

1. README の起動手順どおりに実行できるか
2. `.env.example` をコピーして `.env` を作成する手順が書いてあるか
3. `submission.zip` を解凍して `README.md` から始められるか

---

## 詳細

- **Backend**: [backend/README.md](backend/README.md)
- **Frontend**: [frontend/README.md](frontend/README.md)
- **提出チェックリスト**: [backend/docs/SUBMISSION_CHECKLIST.md](backend/docs/SUBMISSION_CHECKLIST.md)
